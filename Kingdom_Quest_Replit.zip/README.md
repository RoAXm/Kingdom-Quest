# Kingdom Quest — editable multiplayer MVP

A responsive browser party-game prototype for 2–8 players, using Node.js, Express, and Socket.IO. This is an early MVP, not yet a finished commercial game.

## The easiest way to edit it (including from Android)

### Built-in Content Editor
After running or deploying the game, open **`/editor.html`** (for example, `https://your-game-host/editor.html`). The editor lets you change the challenge and settings JSON in a mobile-friendly screen, validate the structure, download each file, and export/import a backup bundle. It does **not** write directly to the live server; after downloading, upload the matching JSON files to your GitHub repository's `content` folder and commit them to deploy the changes.

You can also edit the JSON files directly without changing JavaScript:

- **`content/challenges.json`** — challenge names, prompts, answers, Bible references, and multiple-choice options.
- **`content/game-settings.json`** — number of rounds, challenge/council time limits, starting/max Grace, and basic scoring values.

### Editing on your Android phone with GitHub
1. Open your `kingdom-quest` repository on GitHub in Chrome.
2. Open `content/challenges.json` or `content/game-settings.json`.
3. Tap the pencil/edit button. If the editor is hard to use, turn on Chrome's **Desktop site** option.
4. Change the text or number values, keeping the JSON punctuation intact. Use double quotes around text and commas between fields/items.
5. Tap **Commit changes**. If connected to an auto-deploy service, it will rebuild the game.
6. Check the deployment log and open your live game URL to test the change.

**Safe editing tips:** Make one small change at a time; keep a backup by using GitHub's commit history; do not delete the `type`, `title`, `prompt`, `answer`, or `ref` fields from a challenge. For multiple-choice questions, the correct answer must match one of the `choices` exactly (capitalization is ignored by the game). A challenge with an empty `answer` is host-led/creative rather than automatically graded.

## Add a challenge
1. Open `/editor.html` and edit the challenge list, or open `content/challenges.json` directly in GitHub.
2. Copy one complete `{ ... }` challenge object, including its braces.
3. Paste it into the list, adding a comma between objects.
4. Give it a unique `type`, a short `title`, clear `prompt`, `answer`, and Bible `ref`. Add `choices` for multiple-choice questions if useful.
5. Run `npm test` before deploying if you have access to a terminal. The current test checks that the starter pack has seven entries; if you add/remove entries, update that expectation in `rules.test.js` too. The game's final-round count is separately set in `content/game-settings.json`.

## Run locally
Requires Node.js 18+ (Node 20 or 22 recommended).

```sh
npm install
npm test
npm start
```
Then open `http://localhost:3000` on the same device running the server. For multiple devices on one Wi-Fi network, open the host device's local IP address on each device. A phone browser alone cannot run the Node server in the background reliably; use a Node-capable host for online play.

## Deploy online
Use a Node host that supports WebSockets (for example Render, Railway, Fly.io, or a VPS). Set the build command to `npm install` and start command to `npm start`. The app reads the `PORT` environment variable. Do not use static-only hosting. After deployment, test with two separate devices/browsers using the public HTTPS URL. A deployment has **not** been completed automatically by this source package.

## What's in this MVP
- Mobile-friendly `/editor.html` for editing and validating challenge/settings JSON, downloading individual files, and importing/exporting a backup bundle.
- Create/join rooms with a room code, 2–8 player lobby, ready state, host controls, chat, scoreboard, shared Grace Meter, private role display, basic Council voting, temptation choice, and seven-round progression.
- Server-authoritative room state and role assignment.
- Editable JSON content/settings files and basic tests for the pack and settings.

## Known limits
- Voice chat is not implemented. It requires WebRTC, signaling, HTTPS, microphone permissions, and mute/report controls. No audio is recorded by this prototype.
- Drawing is a host-led/offline sketch activity, not a synchronized canvas.
- Several challenges need host moderation; voting/scoring and win conditions are basic and need playtesting.
- Revelation/Sacrifice/Repentance, private Fallen channel, complete vote-result UI, and synchronized visible countdown remain incomplete.
- Room data is stored in memory and is lost if the server restarts. Reconnect tokens are a prototype, not secure authentication.
- The role distributions for 2–3 players are simplified and not balanced competitive modes.

## Initial role distribution
| Players | Grace Ones | Lukewarm | Fallen |
|---:|---:|---:|---:|
| 2 | 1 | 0 | 1 |
| 3 | 2 | 0 | 1 |
| 4 | 2 | 1 | 1 |
| 5 | 3 | 1 | 1 |
| 6 | 3 | 1 | 2 |
| 7 | 4 | 1 | 2 |
| 8 | 4 | 2 | 2 |

## Bible content note
Prompts use references and paraphrases/reflections. Review wording and references against your preferred Bible translation before publishing a content pack. The game should not claim to judge a player's real faith.
