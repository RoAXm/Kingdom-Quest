
const socket=io();let room=null,myId=null,token=null,roomCode=null,isHost=false,me=null,lastChallengeKey="";
const $=id=>document.getElementById(id);
socket.on("connect",()=>$("connection").textContent="Connected");
socket.on("disconnect",()=>$("connection").textContent="Reconnecting…");
socket.on("errorMsg",m=>{$("homeError").textContent=m;});
socket.on("joined",d=>{myId=d.id;token=d.token;roomCode=d.code;localStorage.setItem("kq-seat",JSON.stringify({code:roomCode,token}));$("home").classList.add("hidden");$("game").classList.remove("hidden");$("code").textContent=roomCode;});
socket.on("room",r=>{room=r;isHost=r.hostId===myId;me=r.players.find(p=>p.id===myId);render();});
socket.on("private",p=>{if(!p)return;$("roleText").textContent=p.role?(p.role+ (p.roleAbility?" — "+p.roleAbility:"")):"Waiting for the host to start.";$("assignment").textContent=p.assignment?"Secret assignment: "+p.assignment:"";document.body.classList.remove("role-grace","role-fallen","role-lukewarm");if(p.faction==="Chosen"||p.role==="Grace One")document.body.classList.add("role-grace");if(p.faction==="Fallen"||p.role==="The Fallen")document.body.classList.add("role-fallen");if(p.faction==="Lukewarm"||p.role==="Lukewarm")document.body.classList.add("role-lukewarm");$("fallenChatCard").classList.toggle("hidden",p.role!=="The Fallen");$("privateNotice").textContent=p.notice||"";$("temptation").classList.toggle("hidden",!p.temptation);$("fallenBox").classList.toggle("hidden",p.role!=="The Fallen");});
socket.on("chat",m=>{const d=document.createElement("div");d.textContent=m.name+": "+m.message;$("chatlog").appendChild(d);$("chatlog").scrollTop=$("chatlog").scrollHeight;});
socket.on("fallenChat",m=>{const d=document.createElement("div");d.textContent=m.name+": "+m.message;$("fallenChatlog").appendChild(d);$("fallenChatlog").scrollTop=$("fallenChatlog").scrollHeight;});
function send(event,data){socket.emit(event,{code:roomCode,...data});}
$("create").onclick=()=>socket.emit("create",{name:$("name").value.trim()||"Host",mode:$("mode").value});
$("copyCode").onclick=async()=>{try{await navigator.clipboard.writeText(roomCode);$("copyCode").textContent="Copied!";}catch(e){prompt("Copy this room code:",roomCode);}};
$("shareRoom").onclick=async()=>{const url=location.origin+"/?room="+encodeURIComponent(roomCode);const text="Join my Kingdom Quest game! Room code: "+roomCode+" — "+url;try{if(navigator.share)await navigator.share({title:"Kingdom Quest invite",text,url});else{await navigator.clipboard.writeText(text);alert("Invite copied. Send it to your friends!");}}catch(e){prompt("Share this invite:",text);}};
$("showJoin").onclick=()=>$("joinBox").classList.toggle("hidden");
$("join").onclick=()=>socket.emit("join",{code:$("joinCode").value.trim(),name:$("name").value.trim()||"Guest"});
$("ready").onclick=()=>send("ready",{ready:!(me&&me.ready)});
$("start").onclick=()=>send("start",{});
$("next").onclick=()=>send("next",{});$("callMeeting").onclick=()=>{if(confirm("Call a meeting now?"))send("callMeeting",{reason:"emergency"});};$("reportBody").onclick=()=>{if(confirm("Report a body and start a meeting?"))send("callMeeting",{reason:"body"});};
$("pause").onclick=()=>send("pause",{});
$("end").onclick=()=>{if(confirm("End this game for everyone?"))send("endGame",{});};
$("submitAnswer").onclick=()=>{send("action",{kind:"answer",value:$("answer").value});$("answer").value="";};
$("reject").onclick=()=>send("action",{kind:"temptation",value:"reject"});
$("accept").onclick=()=>send("action",{kind:"temptation",value:"accept"});
$("castVote").onclick=()=>send("action",{kind:"vote",value:$("publicVote").value});
$("castFallenVote").onclick=()=>send("action",{kind:"fallenVote",value:$("fallenVote").value});
$("sendChat").onclick=()=>{if($("chatInput").value.trim()){send("chat",{message:$("chatInput").value.trim()});$("chatInput").value="";}};
$("sendFallenChat").onclick=()=>{if($("fallenChatInput").value.trim()){send("fallenChat",{message:$("fallenChatInput").value.trim()});$("fallenChatInput").value="";}};
$("fallenChatInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("sendFallenChat").click()});
$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")$("sendChat").click()});
$("replay").onclick=()=>send("next",{});
function render(){if(!room)return;
 $("playerCount").textContent=`(${room.players.length}/8)`;$("players").innerHTML="";
 room.players.forEach(p=>{const d=document.createElement("div");d.className="player";const left=document.createElement("span");left.textContent=p.name+(p.host?" ★":"");if(p.id===myId)left.classList.add("my-name");const right=document.createElement("span");right.className="pill";right.textContent=p.connected?(p.ready?"Ready":"Not ready"):"Reconnecting";d.append(left,right);if(isHost&&p.id!==myId){const b=document.createElement("button");b.className="danger";b.textContent="Remove";b.style.minHeight="34px";b.style.padding="4px 8px";b.onclick=()=>send("remove",{id:p.id});d.append(b)}$("players").append(d);});
 $("scores").innerHTML="";room.scores.sort((a,b)=>b.score-a.score).forEach(p=>{const d=document.createElement("div");d.className="scoreline";d.textContent=p.name;const s=document.createElement("b");s.textContent=p.score+" Impact";d.append(s);$("scores").append(d);});
 $("graceText").textContent=`${room.grace} / ${room.maxGrace}`;$("graceBar").style.width=(room.grace/room.maxGrace*100)+"%";$("rejectCount").textContent=room.rejected;$("conversionCount").textContent=room.conversions;
 $("roundPhase").textContent=room.started?`Round ${room.round}/7 · ${room.mode==="roles"?"Role Mode":"The Temptation"} · ${room.phase}`:"Lobby";
 $("lobbyControls").classList.toggle("hidden",room.started);$("start").classList.toggle("hidden",!isHost||room.started);$("ready").textContent=me&&me.ready?"Ready ✓ (tap to change)":"I’m ready";
 $("rolePlan").textContent=`Mode: ${room.mode==="roles"?"Role Mode (46-role catalog)":"The Temptation (Grace thresholds trigger meetings)"}. Planned faction balance for ${room.players.length} players: ${plan(room.players.length)}.`;
 $("challengeArea").classList.toggle("hidden",!room.started||room.phase==="results"||room.phase==="paused");$("results").classList.toggle("hidden",room.phase!=="results");
 if(room.challenge){const key=room.round+":"+room.challenge.type;if(room.started&&room.phase==="challenge"&&key!==lastChallengeKey){lastChallengeKey=key;showCutscene(room.challenge,room.round);}$("challengeType").textContent=room.challenge.type;$("challengeTitle").textContent=room.challenge.title;$("prompt").textContent=room.challenge.prompt;$("reference").textContent="Scripture / reflection reference: "+room.challenge.ref;
  $("choices").innerHTML="";(room.challenge.choices||[]).forEach(c=>{const b=document.createElement("button");b.className="secondary";b.textContent=c;b.onclick=()=>{ $("answer").value=c;send("action",{kind:"answer",value:c});};$("choices").append(b);});
 }
 $("council").classList.toggle("hidden",room.phase!=="council");$("callMeeting").classList.toggle("hidden",!room.started||room.mode!=="roles"||room.phase!=="challenge");$("reportBody").classList.toggle("hidden",!room.started||room.mode!=="roles"||room.phase!=="challenge");
 $("answerArea").classList.toggle("hidden",room.phase!=="challenge"||["Vision Sketch","Words of Witness","Social Deduction","Council"].includes(room.challenge?.type));
 $("next").classList.toggle("hidden",!isHost||!room.started||room.phase==="results");$("pause").classList.toggle("hidden",!isHost||!room.started);$("end").classList.toggle("hidden",!isHost||!room.started);
 const opts=room.players.filter(p=>p.id!==myId);["publicVote","fallenVote"].forEach(id=>{const sel=$(id),old=sel.value;sel.innerHTML="";opts.forEach(p=>{const o=document.createElement("option");o.value=p.id;o.textContent=p.name;sel.append(o)});if(old)sel.value=old;});
 if(room.phase==="results"){$("outcome").textContent=room.outcome||"Quest complete";$("finalScores").innerHTML="";room.scores.sort((a,b)=>b.score-a.score).forEach((p,i)=>{const d=document.createElement("div");d.className="scoreline";d.textContent=`${i+1}. ${p.name} — ${p.score} Impact`; $("finalScores").append(d);});}
}
function showCutscene(challenge,round){const overlay=document.createElement("div");overlay.style.cssText="position:fixed;inset:0;z-index:50;background:radial-gradient(circle at center,#4b3b27,#090d0b 75%);display:grid;place-items:center;padding:24px";const panel=document.createElement("section");panel.className="card stack";panel.style.cssText="max-width:560px;width:100%;text-align:center;border-color:#d9b76a;box-shadow:0 0 45px #d9a74455";const emblem=document.createElement("div");emblem.style.fontSize="3rem";emblem.textContent="⚔️ 📜";const title=document.createElement("h2");title.textContent="Round "+round+" · The Quest Unfolds";const category=document.createElement("p");category.className="pill";category.textContent=challenge.type;const desc=document.createElement("p");desc.textContent=challenge.title||"A challenge awaits";const verse=document.createElement("p");verse.className="muted";verse.textContent="Scripture clue: "+(challenge.ref||"Explore the wisdom of Scripture");const enter=document.createElement("button");enter.textContent="Enter challenge →";enter.onclick=()=>overlay.remove();panel.append(emblem,title,category,desc,verse,enter);overlay.append(panel);document.body.append(overlay);}
const roomFromUrl=new URLSearchParams(location.search).get("room");if(roomFromUrl){$("joinBox").classList.remove("hidden");$("joinCode").value=roomFromUrl.toUpperCase();}
function plan(n){const p={2:"1 Grace One, 1 Fallen (simplified)",3:"2 Grace Ones, 1 Fallen (simplified)",4:"2 Grace Ones, 1 Lukewarm, 1 Fallen",5:"3 Grace Ones, 1 Lukewarm, 1 Fallen",6:"3 Grace Ones, 1 Lukewarm, 2 Fallen",7:"4 Grace Ones, 1 Lukewarm, 2 Fallen",8:"4 Grace Ones, 2 Lukewarm, 2 Fallen"};return p[n]||"Add players to see setup";}
