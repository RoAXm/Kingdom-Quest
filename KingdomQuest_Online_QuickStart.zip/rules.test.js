const test=require("node:test");const assert=require("node:assert/strict");
function capImpact(current,earned){return Math.min(100-current,earned)+current}
function plan(n){if(n===2)return ["Grace One","The Fallen"];if(n===3)return ["Grace One","Grace One","The Fallen"];if(n===4)return ["Grace One","Grace One","Lukewarm","The Fallen"];if(n===5)return ["Grace One","Grace One","Grace One","Lukewarm","The Fallen"];if(n===6)return ["Grace One","Grace One","Grace One","Lukewarm","The Fallen","The Fallen"];if(n===7)return ["Grace One","Grace One","Grace One","Grace One","Lukewarm","The Fallen","The Fallen"];return ["Grace One","Grace One","Grace One","Grace One","Lukewarm","Lukewarm","The Fallen","The Fallen"];}
test("role distribution supports 2–8 players",()=>{for(let n=2;n<=8;n++)assert.equal(plan(n).length,n);});
test("impact cap is 100",()=>{assert.equal(capImpact(90,50),100);assert.equal(capImpact(0,50),50);});
test("six-player setup matches requested composition",()=>{const p=plan(6);assert.equal(p.filter(x=>x==="Grace One").length,3);assert.equal(p.filter(x=>x==="Lukewarm").length,1);assert.equal(p.filter(x=>x==="The Fallen").length,2);});
test("rejection grace restore cannot exceed max",()=>{const grace=95,max=100,restored=Math.min(max,grace+Math.ceil((max-grace)/2));assert.equal(restored,98);});
test("acceptance halves impact rounding down",()=>{assert.equal(Math.floor(57/2),28);});

const challenges = require("./content/challenges.json");
const settings = require("./content/game-settings.json");
test("editable challenge pack has seven complete challenge entries",()=>{
  assert.equal(challenges.length,7);
  for(const c of challenges){
    assert.equal(typeof c.type,"string");
    assert.equal(typeof c.title,"string");
    assert.equal(typeof c.prompt,"string");
    assert.ok(c.type.length>0 && c.title.length>0 && c.prompt.length>0);
    assert.equal(typeof c.ref,"string");
  }
});
test("editable settings use safe positive values",()=>{
  assert.ok(Number.isInteger(settings.roundCount) && settings.roundCount>0);
  assert.ok(Number.isInteger(settings.challengeSeconds) && settings.challengeSeconds>0);
  assert.ok(Number.isInteger(settings.councilSeconds) && settings.councilSeconds>0);
  assert.ok(settings.maxGrace>0 && settings.startingGrace>=0 && settings.startingGrace<=settings.maxGrace);
  assert.ok(settings.impactCap>0 && settings.correctAnswerImpact>0 && settings.creativeAnswerImpact>0);
});
