const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');

test('public player list does not disclose secret roles or assignments', () => {
  const start = server.indexOf('const publicRoom =');
  const end = server.indexOf('\nfunction emitRoom', start);
  const projection = server.slice(start, end);
  assert.match(projection, /name:p\.name/);
  assert.doesNotMatch(projection, /role:p\.role|assignment:p\.assignment|temptation:p\.temptation/);
});

test('room invite offers copy and share actions with a joinable URL', () => {
  assert.match(html, /id="copyCode"/);
  assert.match(html, /id="shareRoom"/);
  assert.match(html, /\?room=/);
});

test('private role styling is applied only to the local player name', () => {
  assert.match(html, /role-grace \.my-name/);
  assert.match(html, /role-fallen \.my-name/);
  assert.match(html, /role-lukewarm \.my-name/);
  assert.match(html, /if\(p\.id===myId\)left\.classList\.add\("my-name"\)/);
});

test('Fallen private chat is gated by the server role and does not replace public chat', () => {
  assert.match(server, /socket\.on\("fallenChat"/);
  assert.match(server, /p\.faction!=="Fallen"/);
  assert.match(html, /id="chatlog"/);
  assert.match(html, /id="fallenChatlog"/);
});

test('round challenge intro cutscene shows the challenge Scripture reference', () => {
  assert.match(html, /function showCutscene\(challenge,round\)/);
  assert.match(html, /Scripture clue:/);
});
